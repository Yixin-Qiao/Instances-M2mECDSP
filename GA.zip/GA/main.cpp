#include"grasp_2cds.h"
#include <sys/select.h>
#define TEST 1

int outterStep=1;
int innerStep=1;

FILE *logfp;
double ratio=0.8;
double beta=0;
int bestOutter,bestInner,bestTime,bestVal,ls_deep_;
timeval startTime,endTime,nowTime,judgeINItime,judgeNOWtime;
float deep;
float runtime=60;


void copy_(Construct &a,Construct &b){
	a.unDominatedNum=b.unDominatedNum;
	a.canMergeList=b.canMergeList;
	a.isSelected=b.isSelected;
	a.beDominated=b.beDominated;
	a.du=b.du;
	a.earScore=b.earScore;
	a.nexttopQueue=b.nexttopQueue;
	a.tabu_=b.tabu_;
	a.beta=b.beta;
}


int main(int argc,char *argv[]){


	int qiao=5;
	int bestbestnum=2000;
	double bestbestnumtime=3000;
	vector<int>bestnum;bestnum.clear();
	vector<double>my_time;my_time.clear();
	while(qiao--){




	int seed;
	int m_size;
	int RSsize,FSsize;
	float crosssize,mutionsize;
	double p;
	if(argc==1){
		printf("Insufficient parameters!\n");
		return 0;
	}
	if(argc>=3) {ratio=atof(argv[2]);cout<<"ratio:"<<argv[2]<<endl;}
	if(argc>=4) {seed=atoi(argv[3]);}
	//else seed=time(NULL);
	if(argc>=5) outterStep=atoi(argv[4]);
	if(argc>=6) innerStep=atoi(argv[5]);
	if(argc>=7) deep=atof(argv[6]);else deep=0.2;
	if(argc>=8) {ls_deep_=atoi(argv[7]);cout<<argv[7]<<endl;}else ls_deep_=10;
	if(argc>=9) {beta=atof(argv[8]);p=beta;cout<<"beta:"<<argv[8]<<endl;}
	if(argc>=10) m_size=atoi(argv[9]);else m_size=1;
	if(argc>=11) RSsize=atoi(argv[10]);else RSsize=30;
	if(argc>=12) FSsize=atoi(argv[11]);else FSsize=20;
	if(argc>=13) crosssize=atof(argv[12]);else crosssize=0.9;
	if(argc>=14) mutionsize=atof(argv[13]);else mutionsize=0.1;
	if(argc>=15) runtime=atof(argv[14]);else runtime=0;
	p=0.1;
	cout<<"ratio:"<<ratio<<endl;
	cout<<"beta:"<<beta<<endl;
	cout<<"RSsize:"<<RSsize<<endl;
	cout<<"FSsize:"<<FSsize<<endl;
	cout<<"crosssize:"<<crosssize<<endl;
	cout<<"mutionsize:"<<mutionsize<<endl;
	seed=seed*0.12*qiao;cout<<"seed:"<<seed<<endl;
	srand(seed);
	Graph g;
	g.input(argv[1]);
    gettimeofday(&startTime,NULL);
    //times(&startTime);
	if(!g.isConnected()){
		printf("Graph disconnected!\n");
		return 0;
	}



	





	AntCompute ant;
	vector<double> information(g.nodeNum+1,0);
	ant.InitialInformation(information,g.nodeNum);
	vector<vector<int>>chromosome(RSsize+1,vector<int>(g.nodeNum+1,0));
	vector<int>chro_num(RSsize+1,10000);
	vector<int>transformselect(g.nodeNum+1,0);


	int inIterBestNum=20000;
	for(int out_iter=1;nowTime.tv_sec-startTime.tv_sec<runtime;out_iter++){



	
	seed=seed*out_iter*0.37;
	ED e(g);
	Random rd(g.nodeNum);
	Construct c(e,beta);
	Rebuilder r(c);
	Deleter d(r);
	ant.InitialInformation(information,g.nodeNum);
	chromosome.assign(RSsize+1,vector<int>(g.nodeNum+1,0));
	chro_num.assign(RSsize+1,10000);
	transformselect.assign(g.nodeNum+1,0);
	int isFull=0;
	gettimeofday(&judgeINItime,NULL);
	for(int i=1;(i<=100&&judgeNOWtime.tv_sec-judgeINItime.tv_sec<=10)||(isFull!=1);i++){
		e.earDecompose(rd.get());
		if(e.earNum==0){
			printf("No 2-Edge-Connected set exists!\n");
			return 0;
		}
		int i_;
		bool existSolution=c.lsconstructSolution(information,m_size);

		if(!existSolution){
			printf("No solution exists! [%d]\n",i+1);
			return 0;
		}
		r.reConstructGraph();
		int nowbestval=10000;
		for(int j=0;j<innerStep;j++){
			d.deleteUselessNode(m_size);
			if(d.transformans<nowbestval){
				nowbestval=d.transformans;
				transformselect=d.isSelected;
			}
			if(d.updateInformation==1)ant.ComputeInformation(information,g.nodeNum,d.isSelected,p);
			if(d.updated) {
				//printf("^^^ [%d-%d]\n",i+1,j+1);
			}
			//for(int nodede=1;nodede<=g.nodeNum;nodede++){
				//if(d.isSelected[nodede]==0&&d.beDominated[nodede]<m_size){cout<<"!result error!"<<endl;return 0;}
			//}
          	  	if(d.updated){
             	   bestVal=d.bestAns;
             	   bestOutter=i+1,bestInner=j+1; 
             	   //times(&endTime);
             	   if(bestVal<inIterBestNum){gettimeofday(&endTime,NULL);inIterBestNum=bestVal;cout<<"!!!!new result: "<<inIterBestNum<<endl;}
            	} 
				if(nowbestval>10000||nowbestval==0){
					cout<<"||"<<endl;
				}
		}
		for(int u=1;u<=RSsize;u++){
			if(isFull==0){
				if(chro_num[u]==10000){
					chro_num[u]=nowbestval;
					chromosome[u]=transformselect;
					if(u==RSsize)isFull=1;
				}
			}
			else if(nowbestval<chro_num[u]){
				chro_num[u]=nowbestval;
				chromosome[u]=transformselect;
				break;
			}
		}
    	gettimeofday(&nowTime,NULL);
		gettimeofday(&judgeNOWtime,NULL);
	}
	Genetic Ge(g,m_size,d.bestAns);
	Ge.init(RSsize,FSsize,crosssize,mutionsize);
	Ge.RS=chromosome;
	Ge.RSvalue=chro_num;
	Ge.bestans=chro_num[1];
	for(int ter=0;ter<50&&nowTime.tv_sec-startTime.tv_sec<runtime;ter++){
		Ge.tag=0;
		Ge.select();
		Ge.ARS=Ge.FS;
		Ge.ARSvalue=Ge.FSvalue;
		Ge.cross();
		Ge.mutation();
		Ge.correct();
		Ge.selectFromARSToRS(RSsize);
		if(Ge.bestans<inIterBestNum){inIterBestNum=Ge.bestans;cout<<"new result: "<<inIterBestNum<<endl;gettimeofday(&endTime,NULL);}
		if((ter%10)==0)cout<<"iteration:"<<ter<<endl;
		gettimeofday(&nowTime,NULL);
	}




	}//外部迭代，在内部循环迭代到一定程度时，我们对程序重启，每次重启，外部迭代次数+1



	double realTime = endTime.tv_sec-startTime.tv_sec+(endTime.tv_usec-startTime.tv_usec)*1e-6;
	my_time.push_back(realTime);
	bestnum.push_back(inIterBestNum);
	if(inIterBestNum<bestbestnum){
		bestbestnum=inIterBestNum;
		bestbestnumtime=realTime;
	}
	else if(inIterBestNum==bestbestnum&&realTime<bestbestnumtime)bestbestnumtime=realTime;
	}
	int best_=0;double Time_=0;
	for(int i=0;i<5;i++){
		best_+=bestnum[i];
		Time_+=my_time[i];
	}
	cout<<"bestnum:" <<bestbestnum<<"   bestnumtime" <<bestbestnumtime<<endl<<"average bestnum:"<<float(float(best_)/float(5))<<"      avetime:"<<Time_/float(5)<<endl;
}






	//double realTime = endTime.tv_sec-startTime.tv_sec+(endTime.tv_usec-startTime.tv_usec)*1e-6;
	//if(bestVal<bestnum){bestnum=bestVal;my_time.clear();my_time.push_back(realTime);}
	//else if(bestVal==bestnum){
	//	my_time.push_back(realTime);
	//	}
	//}
	//double x=0;
	//for(double t:my_time){x=x+t;}x=x/double(my_time.size());
	//cout<<"bestnum:"<<bestnum<<"      bestnum 次数:"<<my_time.size()<<"      avetime:"<<x<<endl;
/////////////////////////////////////////////////////////////////////////////////////////////
	//if((rat*0.2)!=ratio)return false;
	//A[rat]=bestnum;
	//B[rat]=my_time.size();
	//C[rat]=	x;






	//////////////////////////////////////d.ptResult();
#ifdef LOG
	fclose(logfp);
#endif
#ifdef TEST
	//FILE* testfp=fopen("/home/qiao/cpp/ls_grasp/TEXTgai.txt","a+");
//	logfp=stdout;
    //double realTime = endTime.tv_sec-startTime.tv_sec+(endTime.tv_usec-startTime.tv_usec)*1e-6;
    //double realTime = endTime.tms_stime-startTime.tms_stime+endTime.tms_utime-startTime.tms_utime;
    //realTime/=sysconf(_SC_CLK_TCK);
	//fseek(testfp,0,SEEK_END);
	//fprintf(testfp,"\n%d\n%d %d\n%lf\n",bestVal,bestOutter,bestInner,realTime);
	//fclose(testfp);
#endif
//}




////////////////////////////////////////////////////////////////////////////////////////
//cout<<endl;
//cout<<endl;
//cout<<endl;
//for(int rat=0;rat<=6;rat++)
//cout<<"beta:"<<beta<<"bestnum:"<<A[rat]<<"     bestnum 次数:"<<B[rat]<<"    avetime:"<<C[rat]<<endl;


