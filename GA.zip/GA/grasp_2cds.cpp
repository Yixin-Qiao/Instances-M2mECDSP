#include"grasp_2cds.h"
#include <algorithm>

void Graph::init(){
	//edge.reserve(nodeNum+1);
	//edge.clear();
	//edge.resize(nodeNum+1);
	tot=1;
	ver.clear(); ver.push_back(0);	ver.push_back(0);	
	Next.clear(); Next.push_back(0); Next.push_back(0);
	initVec(head,nodeNum+1);
	initVec(vis,nodeNum+1);
	degree.assign(nodeNum+1,0);
}

void Graph::add(int u,int v){
//	ver[++tot]=v,Next[tot]=head[u],head[u]=tot;
	ver.push_back(v),Next.push_back(head[u]),head[u]=++tot;//tot从2开始计算，2-3为一条边的两条分解边
}

bool Graph::isConnected(){
	queue<int> que;
	que.push(1);
	vis[1]=1;
	int visNum=1;
	while(que.size()){
		int t=que.front(); que.pop();
		for(int i=head[t];i;i=Next[i]){
			int y=ver[i];
			if(vis[y]) continue;
			que.push(y);
			vis[y]=1;
			visNum++;
		}
	}
	return visNum==nodeNum;
}

void Graph::input(char *fileName){
	FILE *fp=freopen(fileName,"r",stdin);
	if (fp==NULL) {
		perror("Failed to open file.\n");
		exit(EXIT_FAILURE);
	}
	int nul;
	scanf("%d",&nodeNum);
	scanf("%d",&nul);//edge
	init();
	bool square=false;
	bool is_0=true;
	int u,v;
	if(!square){
		if(is_0==true){
			while(scanf("%d%d",&u,&v)==2){
				u++;v++;
				if(u==v||u<=0||v<=0||u>nodeNum||v>nodeNum) continue;
				add(u,v); add(v,u);
				degree[u]++;degree[v]++;
			}
		}
		else if(is_0==false){
			while(scanf("%d%d",&u,&v)==2){
				if(u==v||u<=0||v<=0||u>nodeNum||v>nodeNum) continue;
				add(u,v); add(v,u);
				degree[u]++;degree[v]++;
			}
		}
	}
	else{
		int c;
		for(int i=1;i<=nodeNum;i++){
			for(int j=1;j<=nodeNum;j++){
				if(scanf("%d",&c)==1&&i<j){
					if(c==1){
						add(i,j);add(j,i);
						degree[i]++;degree[j]++;
					}
				}
			}
		}
	}
}

void Graph::randomEdge(){
	vector<int> tmpVec;
	for(int i=1;i<=nodeNum;i++){
		for(int j=head[i];j;j=Next[j]) tmpVec.push_back(ver[j]);	
		random_shuffle(tmpVec.begin(),tmpVec.end());
		for(int j=head[i];j;j=Next[j]) ver[j]=tmpVec.back(),tmpVec.pop_back();
	}
}

void ED::init(){
    hasEval=1;
	earNum=0;
	initVec(faPath,g.nodeNum+1);
	initVec(vis,g.nodeNum+1);
	initVec(du,g.nodeNum+1);
	initVec(earIndex,g.nodeNum+1,-1);
	earEdge.clear();
	earNodeList.clear();
	earNodeList=vector<vector<int>>(g.nodeNum+1);
	repeatRely.clear();
}

void ED::addRely(int u,int v){
	if(u==-1||v==-1||u==v||repeatRely.count({v,u})) return;
	earEdge[v].push_back(u);
	repeatRely.insert({v,u});
	du[u]++;
}

bool ED::addEar(int x,int y){
	int px=x,py=y;
	vector<int> rollBackList;
	while(px!=0&&earIndex[px]==-1){
        if(earNum!=0) earNodeList[earNum].push_back(px);   
		earIndex[px]=earNum,rollBackList.push_back(px),px=g.ver[faPath[px]^1];
    }
	while(py!=0&&earIndex[py]==-1){
        if(earNum!=0) earNodeList[earNum].push_back(py);
		earIndex[py]=earNum,rollBackList.push_back(py),py=g.ver[faPath[py]^1];//在上一个循环中，px将路径置为0，当py访问共同路径时，遍跳出，在下一个if语句中从这里开始重新置为-1.
    }
	if(earNum==0){
		int t=g.ver[faPath[py]^1];
		px=py;
		int pre=faPath[py];
		while(t!=0){
			int tp=pre;//
			pre=faPath[t];//
			earIndex[t]=-1;//
			int &rFaPath=faPath[t];
			t=g.ver[faPath[t]^1];//
			rFaPath=tp^1;	//再从公共点开始，把置为0的点重新置为-1
		}
	}else if(earIndex[px]<earNum&&earIndex[py]<earNum){//正常的耳,
		// normal loop		
	}else if(earIndex[py]<earNum){//重复边的点作为的耳
        // multiedge (1--2,2--1)
	}else{  // exist bridge, rollBack//桥，找到的x和y都不在耳中
        hasEval=1;
		for(int e : rollBackList) earIndex[e]=-1;
        earNodeList[earNum].clear();
		return false;//错误的耳在回滚的时候不回滚访问vis，这是因为以后要是碰到这个点依然可以根据他的path获得可能的耳
	}
	earEdge.push_back(vector<int>());
	addRely(earNum,earIndex[px]);
	addRely(earNum,earIndex[py]);
	earNum++;
    return true;
}

void ED::bfs(int bfsTimes,int root){
    hasEval=0;
    initVec(vis,g.nodeNum+1); 
    initVec(faPath,g.nodeNum+1); 
    queue<int> que;
    vector<int> inQue(g.nodeNum+1,0);
    if(bfsTimes==0) vis[root]=1,que.push(root),inQue[root]=1;
    else for(int i=1;i<g.nodeNum;i++) if(earIndex[i]!=-1) vis[i]=1,que.push(i),inQue[i]=1;//若上面出现回滚，则bfs在结束后会被再次调用，并进行这一步，即将一归纳耳的点标记访问，没有vis为0，在试图做一次bfs
    while(que.size()){
        int x=que.front(); que.pop(); inQue[x]=0;
		for(int i=g.head[x];i;i=g.Next[i]){
			if(i==(faPath[x]^1)) continue;
			int y=g.ver[i];
            if(vis[y]==0){
                if(!inQue[y]) que.push(y),inQue[y]=1;
                faPath[y]=i;
                vis[y]=1;
            }else if(earIndex[x]==-1||earIndex[y]==-1){
                addEar(x,y);
            }
        }
    }
}

void ED::earDecompose(int root){
	init();
	earIndex[0]=INT_MAX;	// special reason (bfs)
    int bfsTimes=0;
    int selectNodeNum=0;
    while(hasEval){
        bfs(bfsTimes,root),bfsTimes++;
        int allSelect=0;
        for(int i=1;i<=g.nodeNum;i++) if(earIndex[i]!=-1) allSelect++;
        if(allSelect==selectNodeNum) break;
        else selectNodeNum=allSelect;
    } 
	for(int i=1;i<=g.nodeNum;i++) if(earIndex[i]==0) earNodeList[earIndex[i]].push_back(i);//前面的addear第一个耳没有把节点记录进earNodeList中，这里记录一下
#ifdef LOG
	fprintf(logfp,"earNum=%d\n",earNum);
	for(int i=0;i<earNum;i++){
		fprintf(logfp,"P%d:\n",i);
		for(int j=0;j<(int)earNodeList[i].size();j++)
			fprintf(logfp,"%d%c",earNodeList[i][j]," \n"[j==(int)earNodeList[i].size()-1]);
	}
	for(int i=0;i<earNum;i++){
		fprintf(logfp,"ear %d rely:\n",i);
		for(int j=0;j<(int)earEdge[i].size();j++){
			fprintf(logfp,"%d%c",earEdge[i][j]," \n"[j==(int)earEdge[i].size()-1]);
		}
	}
#endif
}

void EarDec::earDecompose(int root){
	init();
	dfs(root,root);
	earNodeList=vector<vector<int>>(earNum);
	for(int i=1;i<=g.nodeNum;i++) if(earIndex[i]>=0) earNodeList[earIndex[i]].push_back(i);
#ifdef LOG
	fprintf(logfp,"earNum=%d\n",earNum);
	for(int i=0;i<earNum;i++){
		fprintf(logfp,"P%d:\n",i);
		for(int j=0;j<(int)earNodeList[i].size();j++)
			fprintf(logfp,"%d%c",earNodeList[i][j]," \n"[j==(int)earNodeList[i].size()-1]);
	}
	for(int i=0;i<earNum;i++){
		fprintf(logfp,"ear %d rely:\n",i);
		for(int j=0;j<(int)earEdge[i].size();j++){
			fprintf(logfp,"%d%c",earEdge[i][j]," \n"[j==(int)earEdge[i].size()-1]);
		}
	}
#endif
}

void EarDec::init(){
	earNum=0;
	initVec(vis,g.nodeNum+1);
	initVec(inStack,g.nodeNum+1);
	dfsStack.clear();
	initVec(earIndex,g.nodeNum+1,-1);
	initVec(prefix,g.nodeNum+1);
	initVec(du,g.nodeNum+1);
	earEdge.clear();
	repeatRely.clear();
	earNodeList.clear();
}

void EarDec::dfs(int x,int fa){
	vis[x]=1;
	inStack[x]=dfsStack.size();
	dfsStack.push_back(x);
	addPrefix(inStack[x],0);
	for(int i=g.head[x];i;i=g.Next[i]){
		int y=g.ver[i];
		if(y==fa) continue;
		if(vis[y]){
			if(earIndex[x]!=-1&&earIndex[y]==-1) addEar(inStack[y]);
			if(earIndex[x]!=-1) continue;
			if(earNum==0) addEar(inStack[y]);	// first loop
			else if(inStack[y]!=-1&&(prefix[inStack[x]]>prefix[inStack[y]]||(inStack[y]==0&&prefix[0]==1)||(inStack[y]!=0&&prefix[inStack[y]]>prefix[inStack[y]-1]))) addEar(inStack[y]);	//other ear
			else if(inStack[y]==-1&&earIndex[x]==-1&&earIndex[y]!=-1) addEar(earIndex[y],-1);
		}else dfs(y,x);
	}
	if(earIndex[x]==-1) vis[x]=0;
	inStack[x]=-1;
	dfsStack.pop_back();
}

inline void EarDec::addPrefix(int index,int val){
	prefix[index]=index?prefix[index-1]+val:val;
}

void EarDec::addEar(int index){
	int len=dfsStack.size()-index;
	int firstEar=-1,lastEar=-1;
	for(int i=0;i<len;i++){
		int &earL=earIndex[dfsStack[i+index]];
		int &earR=earIndex[dfsStack[index+len-1-i]];
		if(earL!=-1&&firstEar==-1) firstEar=earL;
		if(earR!=-1&&lastEar==-1) lastEar=earR;
	}
	for(int i=0;i<len;i++){
		int &earL=earIndex[dfsStack[i+index]];
		if(earL==-1){
			earL=earNum;
			addPrefix(i+index,1);
		}
	}
	earEdge.push_back(vector<int>());
	addRely(earNum,firstEar);
	addRely(earNum,lastEar);
	earNum++;
}

void EarDec::addEar(int x,int){
	int p=dfsStack.size()-1;
	while(earIndex[dfsStack[p]]==-1) p--;
	addEar(p);
	addRely(earNum-1,x);
}

void EarDec::addRely(int u,int v){
	if(u==-1||v==-1||u==v||repeatRely.count({v,u})) return;
	earEdge[v].push_back(u);
	repeatRely.insert({v,u});
	du[u]++;
}

void Construct::mergeEar(int index,int m_size){
	for(int x : e.earNodeList[index]){
		isSelected[x]=1;
		if(beDominated[x]<m_size) {beDominated[x]+=m_size;unDominatedNum--;}
		else beDominated[x]+=m_size;
		for(int i=g.head[x];i;i=g.Next[i]){
			int y=g.ver[i];
			if(beDominated[y]==m_size-1) {beDominated[y]++;unDominatedNum--;}
			else beDominated[y]++;
		}
		//for(int y : g.edge[x]) if(++beDominated[y]==1) unDominatedNum--;
	}
	//earpath.push_back(index);//记录添加的耳的路径

}

void Construct::init(){
	du=e.du;
	canMergeList.clear();
	initVec(earScore,g.nodeNum+1);
	initVec(isSelected,g.nodeNum+1);
	initVec(beDominated,g.nodeNum+1);
}

void Construct::calEarScore(vector<double> &information,int m_size){
	double num=double(double(1)/double(g.nodeNum));
	e.vis.assign(e.vis.size(),-1);//重新赋值vis -1，用做之后记录
	for(int i=0;i<e.earNum;i++){
		earScore[i]=0;
		for(int x : e.earNodeList[i]){
			if(e.vis[x]!=i){
				e.vis[x]=i;
				if(isSelected[e.earNodeList[i][0]]){//这里之不仅可以选取0 也可以选取该耳里的任意一个节点，仅仅是用来确定这个耳里的节点是否被选中（选中是以整体为单位更新isselect的）
					//if(beDominated[x]==1) earScore[i]=earScore[i]+beta*information[x]/num;
					if(beDominated[x]==m_size) earScore[i]--;
				}else{
					//if(beDominated[x]==0) earScore[i]=earScore[i]+beta*information[x]/num;
					if(beDominated[x]<m_size) earScore[i]=earScore[i]+m_size-beDominated[x];
				}
			}
			for(int j=g.head[x];j;j=g.Next[j]){
				int y=g.ver[j];
				if(e.vis[y]!=i){
					e.vis[y]=i;
					if(isSelected[e.earNodeList[i][0]]){
						//if(beDominated[y]==1) earScore[i]=earScore[i]+beta*information[y]/num;
						if(beDominated[y]==m_size) earScore[i]--;
					}else{
						//if(beDominated[y]==0) earScore[i]=earScore[i]+beta*information[y]/num;
						if(beDominated[y]<m_size) earScore[i]=earScore[i]+m_size-beDominated[y];
					}
				}
			}
		}
		double inf=0;
		for(int t:e.earNodeList[i]){
			inf+=information[t];
		}
		earScore[i]/=e.earNodeList[i].size();
		earScore[i]=earScore[i]+beta*inf/(((double)e.earNodeList[i].size())*(num));
	}
}



bool Construct::lsconstructSolution(vector<double> &information,int m_size){


	init();
	calEarScore(information,m_size);	
	unDominatedNum=g.nodeNum;
	queue<int> topQueue;
	topQueue.push(0);

	while(unDominatedNum){
		while(topQueue.size()){
			int t=topQueue.front(); topQueue.pop();
			canMergeList.push_back(t);
		}
		if(canMergeList.empty()) return false;
		double mxScore=-1e9,mnScore=1e9;
        const double eps = 1e-6;
		for(int x : canMergeList){
			mxScore=max(earScore[x],mxScore);
			mnScore=min(earScore[x],mnScore);
		}
		double ratioVal=mnScore+ratio*(mxScore-mnScore);
		vector<int> rclIndex;
		for(int i=0;i<(int)canMergeList.size();i++)//
			if(earScore[canMergeList[i]]>ratioVal-eps)
				rclIndex.push_back(i);
		int p=rclIndex[rand()%rclIndex.size()];
		
		swap(canMergeList[p],canMergeList.back());
		mergeEar(canMergeList.back(),m_size);//更新点的支配和耳的被选择列表
		calEarScore(information,m_size);	
		for(int i=0;i<(int)e.earEdge[canMergeList.back()].size();i++){
			int y=e.earEdge[canMergeList.back()][i];
			if(--du[y]==0) topQueue.push(y);//加入一个耳后，在这里更新这个耳周围的耳的依赖标记，当不再依赖时，将他放入备选耳队列
		}
		canMergeList.pop_back();
	}
	
	/*			for(int nodede=1;nodede<=g.nodeNum;nodede++){
					if(isSelected[nodede]==0&&beDominated[nodede]<m_size){cout<<"ls result error!"<<endl;return 0;}
				}*/
	return true;
}

pair<int,int> Rebuilder::getEnd(int x,int faPath,int dis,vector<int> &pathNode){
	if(newNode.count(x)) return {x,dis};//递归出口
	for(int i=g.head[x];i;i=g.Next[i]){
		int y=g.ver[i];
		if(i==(faPath^1)||!c.isSelected[y]) continue;//排除返回原先节点的可能
		pathNode.push_back(x);
		return getEnd(y,i,dis+1,pathNode);//递归,其中，dis记录深度(节点数)，pathnode记录这条路径上的节点,而y会因为递归传递返回最后一次访问到的节点，这个节点是NewNode中的节点
	}
#ifdef LOG
	fprintf(logfp,"Error in 'getEnt(%d,%d)'.\n",x,faPath);
#endif
	printf("Error in 'getEnt(%d,%d)'.\n",x,faPath);
	return {0,0};	// impossible
}

void Rebuilder::add(int u,int v,int w){
	//ver[++tot]=v,Next[tot]=head[u],head[u]=tot,weight[tot]=w;
	ver.push_back(v),Next.push_back(head[u]),weight.push_back(w),head[u]=++tot;
}

void Rebuilder::init(){
	newNode.clear();
	oriNode.clear(); oriNode.push_back(0);
	ver.clear(); ver.push_back(0); ver.push_back(0);
	weight.clear(); weight.push_back(0); weight.push_back(0);
	Next.clear(); Next.push_back(0); Next.push_back(0);
	newEdgeNode.clear();
	newEdgeNode.push_back(vector<int>());
	newEdgeNode.push_back(vector<int>());
	pivotNodeNum=0;
	tot=1;
}

void Rebuilder::reConstructGraph(){
	init();
	for(int i=1;i<=g.nodeNum;i++){
		if(!c.isSelected[i]) continue;//c即前一步的构造初始解中的一个解，isselect虽然表示一个节点是否被选中作为解，但是他在更新时以一个耳的节点为整体更新的详见MergeEar
		int neiInEar=0;
		for(int j=g.head[i];j;j=g.Next[j]){
			int y=g.ver[j];
			if(c.isSelected[y]) neiInEar++;
		}
		if(neiInEar>2){
			oriNode.push_back(i);//与下方的newnode共同构成相对绝对位置的转换
			newNode[i]=++pivotNodeNum;//重构中优化节点的方式，将度大于三的节点保存起来，其他节点就自动变为被压缩得边
		}
	}
	head=vector<int>(pivotNodeNum+10,0);
	for(int i=1;i<(int)oriNode.size();i++){
		int x=oriNode[i];
		for(int j=g.head[x];j;j=g.Next[j]){
			int y=g.ver[j];
			if(!c.isSelected[y]) continue;
			int z,w;
			vector<int> pathNode;
			tie(z,w)=getEnd(y,j,0,pathNode);//递归返回z：这条优化边的最后一个NewNode节点（非优化边节点）  w：这条边上被优化的节点数
			if(z>=x){
				add(newNode[x],newNode[z],w);
				add(newNode[z],newNode[x],w);
				newEdgeNode.emplace_back(pathNode);
				newEdgeNode.push_back(vector<int>());
			}
		}
	}
#ifdef LOG
	fprintf(logfp,"new node :\n");
	for(int i=1;i<=pivotNodeNum;i++){
		fprintf(logfp,"%d -> %d\n",oriNode[i],i);
		for(int j=head[i];j;j=Next[j]){
			int y=ver[j];
			int w=weight[j];
			fprintf(logfp,"(%d,%d)_%d ",y,w,j);
		}
		fprintf(logfp,"\n");
	}
#endif
}

void Deleter::init(){
	initVec(logicDelete,r.tot+10);
	initVec(tempLogicDelete,r.tot+10);
	initVec(onlyDom,g.nodeNum+1);
	initVec(logicDeleteNode,g.nodeNum+1);
	isSelected=c.isSelected;	// copy
	beDominated=c.beDominated;	// copy
	canDeleteList.clear();
}

bool Deleter::existBridge(){
	dfn=vector<int>(r.pivotNodeNum+1);//int型默认初始化为0
	low=vector<int>(r.pivotNodeNum+1);
	bridgeNum=0;
	tarjanNum=0;
	int num=0;	//connected component
	for(int i=1;i<=r.pivotNodeNum;i++){
		if(!dfn[i]&&logicDeleteNode[i]==0){
			if(++num>1) return true;
			tarjan(i,0);
		}
	}
	return bridgeNum>0;
}

void Deleter::tarjan(int x,int faEdge){
	dfn[x]=low[x]=++tarjanNum;
	for(int i=r.head[x];i;i=r.Next[i]){
		if(tempLogicDelete[i]||logicDelete[i]||i==(faEdge^1)) continue;
		int y=r.ver[i];
		if(!dfn[y]){
			tarjan(y,i);
			low[x]=min(low[x],low[y]);
			if(dfn[x]<low[y]) bridgeNum++;
		}else low[x]=min(low[x],dfn[y]);
	}
}

bool Deleter::checkDeleteNodeDom(vector<int> &deleteList,int index){
	bool ret=1;	
	deleteList.push_back(r.oriNode[index]);
	for(int i=r.head[index];i;i=r.Next[i]){
		if(logicDelete[i]||tempLogicDelete[i]) continue;
		int tempI=min(i,i^1);
		for(int x : r.newEdgeNode[tempI]) deleteList.push_back(x);
	}
	for(int x : deleteList){
		if(beDominated[x]<=m_size+m_size-1){ beDominated[x]-=m_size;ret=0;}
		else beDominated[x]-=m_size;
		for(int i=g.head[x];i;i=g.Next[i]){
			int y=g.ver[i];
			if(--beDominated[y]<=m_size-1) ret=0;
		}
	}	
	if(ret==1) return true;
	for(int x : deleteList){
		beDominated[x]+=m_size;
		for(int i=g.head[x];i;i=g.Next[i]){
			int y=g.ver[i];
			beDominated[y]++;
		}
	}	
	return false;
}

bool Deleter::checkDeleteEdgeDom(int index){
	bool ret=1;	
	for(int x : r.newEdgeNode[index]){
		if(beDominated[x]<=m_size+m_size-1){ beDominated[x]-=m_size;ret=0;}
		else beDominated[x]-=m_size;
		for(int i=g.head[x];i;i=g.Next[i]){
			int y=g.ver[i];
			if(--beDominated[y]<=m_size-1) ret=0;
		}
	}
	if(ret==1) return true;
	for(int x : r.newEdgeNode[index]){
		beDominated[x]+=m_size;
		for(int i=g.head[x];i;i=g.Next[i]){
			int y=g.ver[i];
			beDominated[y]++;
		}
	}
	return false;
}

int Deleter::deleteEdge(int weight,int index){
	if(logicDelete[index]) return 0;
	if(!checkDeleteEdgeDom(index)) return 0;//检查删除后会不会有未被支配的节点
	tempLogicDelete[index]=1;
	tempLogicDelete[index^1]=1;	// pairwise transformation//假设这条边被删除
	if(!existBridge()){
		logicDelete[index]=1;
		logicDelete[index^1]=1;
#ifdef LOG
		fprintf(logfp,"delete success\ndelete nodes: ");
		for(int y : r.newEdgeNode[index]){
			fprintf(logfp,"%d ",y);
		}
		fprintf(logfp,"\n");
#endif
		return weight;
	}
	tempLogicDelete[index]=0;
	tempLogicDelete[index^1]=0;
	/*for(int x : r.newEdgeNode[index]){
		beDominated[x]++;
		for(int i=g.head[x];i;i=g.Next[i]){
			int y=g.ver[i];
			beDominated[y]++;
		}
	}*/
	return 0;
}

int Deleter::deleteNode(int weight,int index){
	vector<int> deleteList;
	if(!checkDeleteNodeDom(deleteList,index)) return 0;//检查删除后会不会有未被支配的节点
	for(int i=r.head[index];i;i=r.Next[i]){
		tempLogicDelete[i]=1;
		tempLogicDelete[i^1]=1;//假设这个定点的周围的边被删除
	}
	logicDeleteNode[index]=1;
	if(!existBridge()){
		for(int i=r.head[index];i;i=r.Next[i]){
			logicDelete[i]=1;
			logicDelete[i^1]=1;
		}
#ifdef LOG
		fprintf(logfp,"delete success\n");
#endif
		return weight;
	}
	logicDeleteNode[index]=0;
	for(int i=r.head[index];i;i=r.Next[i]){
		tempLogicDelete[i]=0;
		tempLogicDelete[i^1]=0;
	}
	/*for(int x : deleteList){
		beDominated[x]++;
		for(int i=g.head[x];i;i=g.Next[i]){
			int y=g.ver[i];
			beDominated[y]++;
		}
	}*/
	return 0;
}

void Deleter::greedyRandomDelete(vector<tuple<int,Type,int>> &canDeleteList){
	vector<int> nodeScoreFix(r.pivotNodeNum+1);
	vector<int> edgeFix(r.tot+1);
	while(canDeleteList.size()){
		int mxScore=INT_MIN,mnScore=INT_MAX,p=0;
		for(auto &x : canDeleteList){
			mxScore=max(get<0>(x),mxScore);
			mnScore=min(get<0>(x),mnScore);
		}
		double rclVal=mnScore+ratio*(mxScore-mnScore);
		for(int i=0;i<(int)canDeleteList.size();i++){
			if(get<0>(canDeleteList[i])>=rclVal)
				swap(canDeleteList[p++],canDeleteList[i]);
		}
		if(p!=0) p=rand()%p;
#ifdef LOG
		fprintf(logfp,"canDeleteList:\n");
		for(auto &e : canDeleteList) fprintf(logfp,"{w=%d, %c, index=%d}\n",get<0>(e),"NE"[get<1>(e)==Type::EDGE],get<2>(e));
		fprintf(logfp,"mx=%d,mn=%d,ratio=%.2lf,rcl=%.2lf\n",mxScore,mnScore,ratio,rclVal);	
		fprintf(logfp,"select {w=%d, %c, index=%d, oriNode=%d}\n",get<0>(canDeleteList[p]),"NE"[get<1>(canDeleteList[p])==Type::EDGE],get<2>(canDeleteList[p]),r.oriNode[get<2>(canDeleteList[p])]);
#endif
		swap(canDeleteList[p],canDeleteList.back());
		auto &ref=canDeleteList.back();
		if(get<1>(ref)==Type::EDGE)
			deleteEdge(get<0>(ref),get<2>(ref));
		else if(get<1>(ref)==Type::NODE)
			deleteNode(get<0>(ref),get<2>(ref));
		if(get<1>(ref)==Type::EDGE){		//calculate fix
			nodeScoreFix[r.ver[get<2>(ref)]]-=get<0>(ref);		
			nodeScoreFix[r.ver[get<2>(ref)^1]]-=get<0>(ref);		
		}else if(get<1>(ref)==Type::NODE){
			for(int i=r.head[get<2>(ref)];i;i=r.Next[i]){
				edgeFix[(i|1)-1]=1;		// set the lowest bit be 0
				nodeScoreFix[r.ver[i]]-=r.weight[i];		
				nodeScoreFix[r.ver[i^1]]-=r.weight[i^1];		
			}
		}	
		Type refType=get<1>(ref);
		canDeleteList.pop_back();
		for(auto &e : canDeleteList){
			if(get<1>(e)==Type::NODE){
#ifdef LOG
				if(nodeScoreFix[get<2>(e)]) fprintf(logfp,"nodeFix: node %d -= %d, oriNode=%d\n",get<2>(e),nodeScoreFix[get<2>(e)],r.oriNode[get<2>(e)]);
#endif
				get<0>(e)+=nodeScoreFix[get<2>(e)];	
				nodeScoreFix[get<2>(e)]=0;		//clear fix
			}
		}
		if(refType==Type::NODE){
			int p=canDeleteList.size()-1;
			for(int i=p;i>=0;i--){
				auto &e=canDeleteList[i];
				if(get<1>(e)==Type::EDGE&&edgeFix[get<2>(e)]==1){
					swap(e,canDeleteList[p--]);
					edgeFix[get<2>(e)]=0;			//clear fix	
#ifdef LOG
					fprintf(logfp,"edgeFix: edge %d cover\n",get<2>(e));
#endif
				}
			}	
			while(canDeleteList.size()>p+1) canDeleteList.pop_back();
		}
	}
}

void Deleter::randomDelete(vector<tuple<int,Type,int>> &canDeleteList){
    random_shuffle(canDeleteList.begin(),canDeleteList.end());
	for(auto &e : canDeleteList){
#ifdef LOG
		fprintf(logfp,"try to delete{%d,%c}\n",get<2>(e),"NE"[get<1>(e)==Type::EDGE]);
#endif
		if(get<1>(e)==Type::EDGE)
			deleteEdge(get<0>(e),get<2>(e));
		else if(get<1>(e)==Type::NODE)
			deleteNode(get<0>(e),get<2>(e));
	}
}

void Deleter::deleteUselessNode(int msize){
	init();
	m_size=msize;
	for(int i=1;i<=g.nodeNum;i++){
		if(c.beDominated[i]!=m_size) continue;
		for(int j=g.head[i];j;j=g.Next[j]){
			int y=g.ver[j];
			if(c.isSelected[y]) onlyDom[y]=1;//找出被支配的点仅有一条边和耳相连，并记录，在下面设置为该解中的点不能删除
		}
	}
	for(int i=2;i<r.tot;i+=2){//这里之所以选取2可以看看重构最后的newEdgeNode，tot 保存新的边的数量
		if(m_size==2){
			if(r.weight[i]==1){
				bool canNotdelete=0;
				for(int y : r.newEdgeNode[i]){
					if(onlyDom[y]==1){
						canNotdelete=1;
						break;
					}
				}
				if(canNotdelete==0)
					canDeleteList.push_back(make_tuple(r.weight[i],Type::EDGE,i));//这是第i个边，权重为weight[i]，不能删除//这里记录可删除的边
			}
		}
		else {
			if(r.weight[i]>0&&r.weight[i]<=2){
				bool canNotdelete=0;
				for(int y : r.newEdgeNode[i]){
					if(onlyDom[y]==1){
						canNotdelete=1;
						break;
					}
				}
				if(canNotdelete==0)
					canDeleteList.push_back(make_tuple(r.weight[i],Type::EDGE,i));//这是第i个边，权重为weight[i]，不能删除//这里记录可删除的边
			}
		}
	}
	for(int i=1;i<=r.pivotNodeNum;i++){//pivotnodenum是重构后节点的数量
		int weight_2=0,weight_0=0,nodeWeight=1;
		for(int j=r.head[i];j;j=r.Next[j]){
			int w=r.weight[j];
			nodeWeight+=w;
			if(w>=2) weight_2++;
			else if(w==0) weight_0++;
		}
		if(weight_2==0&&weight_0!=0&&onlyDom[r.oriNode[i]]==0)
			canDeleteList.push_back(make_tuple(nodeWeight,Type::NODE,i));//记录可删除的顶点
	}
#ifdef GREEDY
	greedyRandomDelete(canDeleteList);
#else
	randomDelete(canDeleteList);
#endif
	for(int i=2;i<(int)logicDelete.size();i+=2){
		if(logicDelete[i]==0) continue;
		for(int x : r.newEdgeNode[i]){
			isSelected[x]=0;
		}
	}
	for(int i=1;i<=g.nodeNum;i++) if(logicDeleteNode[i]) isSelected[r.oriNode[i]]=0;
	int weightSum=0;
	for(int i=1;i<=g.nodeNum;i++) weightSum+=isSelected[i];
#ifdef LOG
	fprintf(logfp,"ans=%d\n",weightSum);
#endif
	updateResult(weightSum);
	
	/*			for(int nodede=1;nodede<=g.nodeNum;nodede++){
					if(isSelected[nodede]==0&&beDominated[nodede]<m_size){cout<<"de result error!"<<endl;}
				}*/
}

void Deleter::updateResult(int ans){
	transformans=ans;
	if(ans<=bestAns)updateInformation=1;
	else updateInformation=0;
	if(ans<bestAns){
		bestAns=ans;
		updated=1;
		if(ans<0){
			exit(EXIT_FAILURE);  // �������򲢷���һ��״̬��
        }
		bestSol.clear();
		for(int i=1;i<=g.nodeNum;i++) if(isSelected[i]) bestSol.push_back(i);
		//printf("Local optimal solution: %d\n",bestAns);
	}else{
		updated=0;
	}
}

void Deleter::ptResult(){
	printf("The optimal solution found selected %d nodes, which are: \n",bestAns);
	for(int i=0;i<bestAns;i++)
		printf("%d%c",bestSol[i]," \n"[i==bestAns-1]);
}

Random::Random(int x){
	buffer=vector<int>(x);
	for(int i=0;i<(int)buffer.size();i++) buffer[i]=i+1;
	cnt=x;
}

int Random::get(){
	if(cnt==0) cnt=buffer.size();
	int index=rand()%cnt;
	swap(buffer[index],buffer[cnt-1]);
	return buffer[--cnt];
}
void AntCompute::InitialInformation(vector<double>&information,int NodeNum){
	double initial=double(double(1)/double(NodeNum));
	for(int u=1;u<=NodeNum;u++){
		information[u]=initial;
	}
}
void AntCompute::ComputeInformation(vector<double>&information,int NodeNum,vector<int>&select,double p){
	double reduce=0;
	double t;
	int num=0;
	for(int u=1;u<=NodeNum;u++){
		if(select[u]==0){
			t=p*information[u];
			information[u]=information[u]-t;
			reduce=reduce+t;
			num++;
		}
	}
	num=NodeNum-num;
	double increase=reduce/float(num);
	for(int u=1;u<=NodeNum;u++){
		if(select[u]==1){
			information[u]=information[u]+increase;
			if(information[u]>1){InitialInformation(information,NodeNum);cout<<";;;"<<endl;}
		}
	}
}
void Genetic::init(int a,int b,float c,float d){
	RS.assign(a+1,vector<int>(g.nodeNum+1,0));RSvalue.assign(a+1,0);
	FS.assign(b+1,vector<int>(g.nodeNum+1,0));FSvalue.assign(a+1,0);
	RSsize=a;FSsize=b;crosssize=c;mutationsize=d;
}
void Genetic::select(){
	FS.clear();FSvalue.clear();
	FS.push_back(vector<int>(g.nodeNum+1,0));FSvalue.push_back(0);
	vector<int>vis(RSsize+1,0);
	for(int t=1;t<=FSsize;t++){
		int min=10000,tag=0;
		for(int u=1;u<=RSsize;u++){
			if(vis[u]==0&&min>RSvalue[u]){
				min=RSvalue[u];
				tag=u;
			}
		}
		if(tag==0)
			cout<<"tag error"<<endl;
		FS.push_back(RS[tag]);
		FSvalue.push_back(min);
		vis[tag]=1;
	}
}
void Genetic::cross(){
	mt19937 T(rand());
	shuffle(FS.begin()+1, FS.end(), T);
	uniform_int_distribution<int> distribution(1, g.nodeNum*0.1);
	ARS.clear();
	ARS.push_back(vector<int>());
	int ARSsize=0;
	for(int i=1;i<=round(FSsize*crosssize);i++){
		//cout<<"SIZE:"<<round(FSsize*crosssize)<<endl;
		for(int j=1;j<=FSsize;j++){
			if(i==j)continue;
			//int randomInt = distribution(T);
			int randomInt = 1;
			ARS.push_back(vector<int>());
			ARSsize++;
			ARS[ARSsize].clear();
			ARS[ARSsize].push_back(0);
			int k;
			for(k=1;k<randomInt;k++){
				ARS[ARSsize].push_back(FS[i][k]);
			}
			int temp=randomInt+g.nodeNum*0.9;
			for(;randomInt<=temp;randomInt++){
				if(FS[j][randomInt]==1||FS[i][randomInt]==1)ARS[ARSsize].push_back(1);
				else ARS[ARSsize].push_back(0);
			}
			for(k=temp+1;k<=g.nodeNum;k++){
				ARS[ARSsize].push_back(FS[i][k]);
			}//cross
		}
	}
	for(int i=1;i<=FSsize;i++){
		ARSsize++;
		ARS.push_back(FS[i]);
	}
	if(ARS.size()-1!=round(FSsize*crosssize*(FSsize-1)+FSsize)||ARS.size()-1!=ARSsize)cout<<"ARS "<<ARS.size()<<"  size:"<<round(FSsize*crosssize*(FSsize-1)+FSsize)<<endl;
}

void Genetic::mutation(){
	mt19937 T(rand());
	uniform_real_distribution<double> distribution(0.0, 1.0);
	for(int i=1;i<=ARS.size()-1-FSsize;i++){
		for(int j=1;j<=g.nodeNum;j++){
			if(distribution(T)<mutationsize&&ARS[i][j]==0)ARS[i][j]=1;
		}
	}//mutation
	ARSvalue.assign(ARS.size(),0);
	for(int i=1;i<=ARS.size()-1;i++){
		for(int j=1;j<=g.nodeNum;j++){
			if(ARS[i][j]==1)ARSvalue[i]++;
		}
		//if(ARSvalue[i]<200){
			//cout<<"zhe"<<endl;
		//}
	}
}
void Genetic::correct(){
	/*for(int i=1;i<=ARS.size()-1;i++)
		for(int j=1;j<=g.nodeNum;j++){
			if(ARS[i][j]==1)ARSvalue[i]++;
		}*/
	for(int i=1;i<=ARS.size()-1;i++){
		deleteAloneNode(ARS[i]);
		int ans=ECDS(ARS[i]);
		ARSvalue[i]=ans;
		vector<int>S0andConnector;S0andConnector.clear();
		for(int k=1;k<=g.nodeNum;k++)if(ARS[i][k]==1)S0andConnector.push_back(k);
		/*if(existBridge(S0andConnector)||S0andConnector.empty()){
			cout<<"连同支配集错误"<<endl;
		}*/
		vector<int>beDominated(g.nodeNum+1,0);
		for(int j=1;j<=g.nodeNum;j++){
			if(ARS[i][j]==1)beDominated[j]+=m_size;
			for(int k=g.head[j];k;k=g.Next[k]){
				int neighbor=g.ver[k];
				if(ARS[i][neighbor]==1)beDominated[j]++;
			}
		}
	/*	for(int nodede=1;nodede<=g.nodeNum;nodede++){
			if(ARS[i][nodede]==0&&beDominated[nodede]<m_size){
				cout<<"de result error!"<<endl;
			}
		}*/
		if(ans<bestans){bestans=ans;tag=1;}
	}
}
void Genetic::deleteAloneNode(vector<int>&S){
	int judge=1;
	while(judge==1)
		judge=0;
		for(int i=1;i<=g.nodeNum;i++){
			if(S[i]==0)continue;
			int isAloneNode=0;
			for(int j=g.head[i];j;j=g.Next[j]){
				int neighbor=g.ver[j];
				if(S[neighbor]==1)isAloneNode++;
			}
			if(isAloneNode<=1){S[i]=0;judge=1;}
	}
}
void Genetic::selectFromARSToRS(int a){
	RS.clear();RS.assign(a+1,vector<int>(g.nodeNum+1,0));RSvalue.assign(a+1,10000);
	int size=round(FSsize*crosssize*(FSsize-1)+FSsize);
	for(int i=1;i<=RS.size()-1;i++){
		RS[i]=ARS[i];
		RSvalue[i]=ARSvalue[i];
	}
	for(int i=1;i<=size;i++){
		for(int j=1;j<=RS.size()-1;j++){
			if(ARSvalue[i]<RSvalue[j]){
				RSvalue[j]=ARSvalue[i];
				RS[j]=ARS[i];
				ARSvalue[i]=10000;//已被加入过，标记以后不会被选中
			}
		}
	}
}
int Genetic::ECDS(vector<int>&S){
	//connected(S);
	int num=0;
	for(int i=1;i<=g.nodeNum;i++)if(S[i]==1)num++;
	for(int t=0;t<5;t++)refine_SandDelete(S);
	int num1=0;
	for(int i=1;i<=g.nodeNum;i++)if(S[i]==1)num1++;
	//if((num-num1)>0)cout<<"success!"<<endl;
	//cout<<endl;
	return num1;
}
void Genetic::andDelete(vector<int>&S){
    //for(int i=1;i<g.nodeNum;i++) if(isSelected[i]){
    //    beDominated[i]+=m_size;
    //    for(int j=g.head[i];j;j=g.Next[j]){
    //        int y=g.ver[j];
    //        beDominated[y]++;
    //   }
    //}
	vector<int>logicDelete(g.nodeNum+1,0);
	vector<int>beDominated(g.nodeNum+1,0);
	for(int i=1;i<=g.nodeNum;i++){
		if(S[i]==1) {beDominated[i]+=m_size;
			for(int j=g.head[i];j;j=g.Next[j]){
				int y=g.ver[j];
				beDominated[y]++;
		}
		}
		//for(int y : g.edge[x]) if(++beDominated[y]==1) unDominatedNum--;
	}
	for(int nodede=1;nodede<=g.nodeNum;nodede++){
		if(S[nodede]==0&&beDominated[nodede]<m_size){cout<<"copyde result error!"<<endl;}
	}
    vector<int> deleteList; 
    for(int i=1;i<=g.nodeNum;i++) deleteList.push_back(i);
    random_shuffle(deleteList.begin(),deleteList.end());
    for(int x : deleteList){
        if(S[x]==0) continue;
        int dom=1;
        //if(--beDominated[x]==m_size-1) dom=0;
		
		if(beDominated[x]<=m_size+m_size-1){ beDominated[x]-=m_size;dom=0;}
		else beDominated[x]-=m_size;
        for(int i=g.head[x];i;i=g.Next[i]){
            int y=g.ver[i];
            //if(--beDominated[y]==m_size-1) dom=0;
			if(--beDominated[y]<=m_size-1) dom=0;
        }
        logicDelete[x]=1;
        if(existBridge(S,logicDelete)||dom==0){
            logicDelete[x]=0;
			beDominated[x]+=m_size;
            for(int i=g.head[x];i;i=g.Next[i]){
                int y=g.ver[i];
				beDominated[y]++;
            }
        } 
    }
	
				for(int nodede=1;nodede<=g.nodeNum;nodede++){
					if(S[nodede]==0&&beDominated[nodede]<m_size){cout<<"de result error!"<<endl;}
				}
}
bool Genetic::existBridge(vector<int>&S,vector<int>&logicDelete){
	vector<int>dfn(g.nodeNum+1);
	vector<int>low(g.nodeNum+1);
    int bridgeNum=0;
    int tarjanNum=0;
    int num=0; 
    for(int i=1;i<=g.nodeNum;i++){
        if(!dfn[i]&&S[i]&&!logicDelete[i]){
			if(++num>1) return true;
			tarjan(i,0,S,logicDelete,dfn,low,bridgeNum,tarjanNum);
        }
    } 
	return bridgeNum>0;
}
void Genetic::tarjan(int x,int faEdge,vector<int>&S,vector<int>&logicDelete,vector<int>&dfn,vector<int>&low,int &bridgeNum,int &tarjanNum){
	dfn[x]=low[x]=++tarjanNum;
    for(int i=g.head[x];i;i=g.Next[i]){
		int y=g.ver[i];
        if(!S[y]||i==(faEdge^1)||logicDelete[y]) continue;
		if(!dfn[y]){
			tarjan(y,i,S,logicDelete,dfn,low,bridgeNum,tarjanNum);
			low[x]=min(low[x],low[y]);
			if(dfn[x]<low[y]) bridgeNum++;
		}else low[x]=min(low[x],dfn[y]);
    }
}





















void Genetic::connected(vector<int>&S){
	PDS(S);
	vector<int>tag(g.nodeNum+1,0);
	if(PDSdeleteDominatingNode(S,tag)!=0)cout<<"dominatingNode error"<<endl;
	findConnectedDominatingSet(S);	
	int judge=0;
	for(int i=1;i<=g.nodeNum;i++){
		if(S[i]==0){
			int t=0;
			for(int j=g.head[i];j;j=g.Next[j]){
				int y=g.ver[j];
				if(S[y]==1)t=1;
			}
			if(t==0)judge=1;
		}
	}
	vector<int>vis(g.nodeNum+1,0);
	queue<int> Q;int num=0;
	for(int k=1;k<=g.nodeNum;k++){
		if(S[k]==1&&vis[k]==0){num++;
			Q.push(k);
			vis[k]=1;
			while(!Q.empty()){
				int x=Q.front();
				Q.pop();
    			for(int j=g.head[x];j;j=g.Next[j]){
					int neighbor=g.ver[j];
					if(S[neighbor]==1&&vis[neighbor]==0){
						vis[neighbor]=1;
						Q.push(neighbor);
					}
				}
			}
		}
	}
	if(judge==1||num>=2)cout<<"connected Dominating Set error"<<endl;
	if(m_size==2)expenDominating(S);
	vector<int>S0;S0.clear();
	for(int i=1;i<=g.nodeNum;i++){
		if(S[i]==1)S0.push_back(i);
	}
	computeECDS(S0);
	S.assign(g.nodeNum+1,0);
	for(int i:S0){
		S[i]=1;
	}
	

	//cout<<endl;

}//连通当前解S；
void Genetic::PDS(vector<int>&S){
	vector<int>tag(g.nodeNum+1,0);
	int noDominating=PDSdeleteDominatingNode(S,tag);
	while(noDominating){
		int u=int(time(NULL))%g.nodeNum;
		for(;u<=g.nodeNum;){
			if(u==0)u++;
			if(tag[u]==0)break;
			u++;
			if(u>g.nodeNum)u=1;
		}
		for(int j=g.head[u];j;j=g.Next[j]){
			int y=g.ver[j];
			if(tag[y]==0){
				tag[y]=1;noDominating--;
			}
		}
		tag[u]=1;noDominating--;S[u]=1;
	}
}
int Genetic::PDSdeleteDominatingNode(vector<int>&S,vector<int>&tag){
	int noDominating=0;
	for(int i=1;i<=g.nodeNum;i++){
		if(S[i]==1){
			tag[i]=1;
			for(int j=g.head[i];j;j=g.Next[j]){
				int y=g.ver[j];
				tag[y]=1;
			}
		}
	}
	for(int i=1;i<=g.nodeNum;i++){
		if(tag[i]==0)noDominating++;
	}
	return noDominating;
}
void Genetic::findConnectedDominatingSet(vector<int>&S){
	vector<int> component(g.nodeNum+1,0);
	for(int i=1;i<=g.nodeNum;i++){
		component[i]=i;
	}
	bfs(S,component);
	while (!allComponentsConnected(S,component)) {
        int connector=findCanMergeConnectors(S,component);
        if(connector!=-1&&S[connector]==0){
			S[connector]=1;
            bfs(S,component);
        }
		else cout<<"connector error!"<<endl;
    }
}
void Genetic::bfs(vector<int>&S,vector<int>&component){
    queue<int>q;
    vector<int>visit(g.nodeNum+1,0);
	for(int i=1;i<=g.nodeNum;i++){
		if(S[i]==0||visit[i]==1)continue;
	    int t=component[i];
	    q.push(i);
	    visit[i]=1;
	    while(!q.empty()){
	        int u=q.front();
	        q.pop();
	        for(int j=g.head[u];j;j=g.Next[j]){
				int y=g.ver[j];
	            if(S[y]==1&&visit[y]==0){
	                q.push(y);
	                component[y]=t;
	                visit[y]=1;
 	           }
	        }
	    }
	}
}
bool Genetic::allComponentsConnected(vector<int>&S,vector<int>&component){
    int com=-1;
    for(int u=1;u<=g.nodeNum;u++){
        if(S[u]==1){
            if(com==-1)com=component[u];
            else if(com!=component[u])return false;
        }
    }
    return true;
}
int Genetic::findCanMergeConnectors(vector<int>&S,vector<int>&component){
    int maxConnectors=-1;
    int maxConnectorsDegree=-1; 
    vector<int>compon;
    int isHave;
    for(int u=1;u<=g.nodeNum;u++){
        if(S[u]==0){
            for(int j=g.head[u];j;j=g.Next[j]){
				int neighbor=g.ver[j];
                if(S[neighbor]==1){
                    isHave=-1;
                    for(int find_:compon){
                        if(find_==component[neighbor])isHave=1;
                    }
                    if(isHave==-1){
                        compon.push_back(component[neighbor]);
                    }
                }
            }
            int t=compon.size();
            if((t>=1)&&(t>maxConnectorsDegree)){
                maxConnectorsDegree=t;
                maxConnectors=u;
            }
            else if(t>=1&&t==maxConnectorsDegree&&g.degree[u]>g.degree[maxConnectors]){
                maxConnectorsDegree=t;
                maxConnectors=u;
            }
            compon.clear();
        }
    }
    if(maxConnectors!=-1&&maxConnectorsDegree>=1)return maxConnectors;
    else return -1;
}


void Genetic::computeECDS(vector<int>&S0){
	vector<int>isBlue(g.nodeNum+1,0);
	vector<int>isWhite(g.nodeNum+1,1);
	vector<int>isRed(g.nodeNum+1,0);
	vector<int>eblock_id(g.nodeNum+1,20000);
    computeEblocks(S0,isBlue,isWhite,isRed,eblock_id);
    vector<int>S0andConnector=S0;
	int judge=0;
	for(int e=1;e<=g.nodeNum;e++){
		if(eblock_id[e]!=20000)judge=1;
	}
    while(computeEblocksNum(S0andConnector,eblock_id)>1){
        int L1=findL1Connector(S0andConnector,eblock_id);
        if(L1!=-1){
            S0andConnector.push_back(L1);
            computeEblocks(S0andConnector,isBlue,isWhite,isRed,eblock_id);
        }
        else {
            pair<int,int> L2=findL2Connector(S0andConnector,eblock_id);
            if(L2.first!=-1){
                S0andConnector.push_back(L2.first);
                S0andConnector.push_back(L2.second);
                computeEblocks(S0andConnector,isBlue,isWhite,isRed,eblock_id);
            }
            else 
                cout<<"connector error!"<<endl;
        }
    }
    if(existBridge(S0andConnector)){
		cout<<"连同支配集错误"<<endl;
	}
    int num=int(S0andConnector.size());
	S0=S0andConnector;
    //cout<<"二边连同支配集节点数："<<num<<endl;
}
void Genetic::computeEblocks(vector<int>S0andConnector,vector<int>&isBlue,vector<int>&isWhite,vector<int>&isRed,vector<int>&eblock_id){
	vector<int>isExistInBRANCH(g.nodeNum+1,0);
	vector<int>isEdgeInBRANCH(g.tot+1,0);
	vector<vector<int>>treeneighbor;
    treeneighbor.clear();
    treeneighbor.push_back(vector<int>());
    for(int i=1;i<=g.nodeNum;i++){
        treeneighbor.push_back(vector<int>());
    }
    constructBFSTree(S0andConnector,isExistInBRANCH,treeneighbor,isEdgeInBRANCH);
    vector<int>Edone;
    vector<int>Sundo;
    vector<int>Circle;
    Edone.clear();
    Sundo=S0andConnector;
    for(int u=0;u<S0andConnector.size();u++){
        int minID=Sundo.front();
        for(int i:Sundo){
            if(i<minID){minID=i;}
        }//挑选最小ID节点
        vector<int>notBRANCHedge;//在下面记录minID不在树中的边
        notBRANCHedge.clear();
        for(int j=g.head[minID];j;j=g.Next[j]){
			int neighbor=g.ver[j];//我们在后面加入isExistInBRANCH[neighbor]==1来确保该边在支配集中
            /*bool istreeneighbor=false;
            for(int tneighbor:treeneighbor[minID]){
                if(neighbor==tneighbor)istreeneighbor=true;
            }
            if(istreeneighbor==false&&isExistInBRANCH[neighbor]==1){
                notBRANCHedge.push_back(neighbor);
            }*/
			if(isEdgeInBRANCH[j]!=1){notBRANCHedge.push_back(j);notBRANCHedge.push_back(j^1);}
        }//寻找不在树中的边，但他的邻居却在树中
        if(int(notBRANCHedge.size())==0){
            if(isWhite[minID]==1){
                isBlue[minID]=1;
                isWhite[minID]=0;
                isRed[minID]=0;
                eblock_id[minID]=minID;
            }
        }
		else{
            for(int NoInTreeNeighbor:notBRANCHedge){
                bool isINEdone=false;
                //for(int e:Edone)if(g.ver[NoInTreeNeighbor]==e)isINEdone=true;
                if(isINEdone==true)continue;
                if(isExistInBRANCH[g.ver[NoInTreeNeighbor]]==1){//存在环 下面找出环并进行进一步判断修改  使用线性探测法探测环
                    int detect=minID;
                    Circle.clear();
                    Circle.push_back(minID);
                    vector<int>CircleVisit(g.tot+1,0);
                    detect=g.ver[NoInTreeNeighbor];
                    CircleVisit[NoInTreeNeighbor]=1;
					CircleVisit[NoInTreeNeighbor^1]=1;
                    //CircleVisit[minID]=1;
                    while(detect!=minID){
                        int nowNode;
                        nowNode=detect;
						for(int edge=g.head[detect];edge;edge=g.Next[edge]){
                            if(int(Circle.size())==0)cout<<"circle 查找错误"<<endl;//找不到环的错误情况
                            if(isEdgeInBRANCH[edge]==1&&CircleVisit[edge]==0){
                                Circle.push_back(detect);
                                detect=g.ver[edge];
                                CircleVisit[edge]=1;CircleVisit[edge^1]=1;
                                break;
                            }
                        }
                        if(detect==nowNode){
                            detect=Circle.back();
                            Circle.pop_back();
                        }
                    }
                    bool HaveRedNode=false;
                    for(int cirNode:Circle){
                        if(isRed[cirNode]==1)HaveRedNode=true;
                    }
                    if(HaveRedNode==false){
                        int K1=Circle.front();
                        for(int cirNode:Circle){
                            if(cirNode<K1)K1=cirNode;
                        }
                        for(int cirNode:Circle){
                            eblock_id[cirNode]=K1;
                            isRed[cirNode]=1;
                            isBlue[cirNode]=0;
                            isWhite[cirNode]=0;
                        }
                    }
                    else{
                        vector<int>Q;
                        for(int cirNode:Circle){
                            bool isINQ=false;
                            for(int n:Q){
                                if(eblock_id[cirNode]==n)isINQ=true;
                            }
                            if(isINQ==false)Q.push_back(eblock_id[cirNode]);
                        }
                        int K2=Q.front();
                        for(int q:Q){
                            if(q<K2)K2=q;
                        }
                        for(int cirNode:Circle){
                            eblock_id[cirNode]=K2;
                            isRed[cirNode]=1;
                            isBlue[cirNode]=0;
                            isWhite[cirNode]=0;
                        }
                        for(int u=1;u<g.nodeNum;u++){
                            bool isINQ_K2_MAX=false;
                            for(int q:Q){
                                if(q!=K2&&q!=20000&&eblock_id[u]==q)isINQ_K2_MAX=true;//该结点的eblock_id在Q-K2-MAX 中；
                            }
                            if(isINQ_K2_MAX==true){
                                eblock_id[u]=K2;
                            }
                        }//end for
                    }//环中存在红色节点的处理办法//end if
                }
            }//end for
			//for(int edge=g.head[minID];edge;edge=g.Next[edge])
            //Edone.push_back(edge^1);//所有指向该节点的边都被处理过了，因为我们使用的是节点抽象表示，因此在这里记录该节点即可
        }
        for(auto s=Sundo.begin();s!=Sundo.end();){
            if(*s==minID){
                Sundo.erase(s);
            }
            else s++;
        }
    }
}
void Genetic::constructBFSTree(vector<int> T,vector<int>&isExistInBRANCH,vector<vector<int>>&treeneighbor,vector<int>&isEdgeInBRANCH){
    /*vector<int>visit(g.nodeNum+1,0);//visit initial
    for(int u=1;u<=g.nodeNum;u++){
        isExistInBRANCH[u]=0;
    }//初始化是否在BRANCH中的数组
    for(int u=0;u<T.size();u++){
        isExistInBRANCH[T[u]]=1;
    }
    queue<int>q;
    q.push(T.front());
    while(!q.empty()){
        int u=q.front();
        q.pop();
        visit[u]=1;
        for(int j=g.head[u];j;j=g.Next[j]){
			int neighbor=g.ver[j];
            if(isExistInBRANCH[neighbor]==1&&visit[neighbor]==0){
                treeneighbor[u].push_back(neighbor);
                treeneighbor[neighbor].push_back(u);//给他的子节点中压入父节点邻居i
                visit[neighbor]=1;
                q.push(neighbor);
            }
        }
    }*/
	    vector<int>visit(g.nodeNum+1,0);//visit initial
    for(int u=1;u<=g.nodeNum;u++){
        isExistInBRANCH[u]=0;
    }//初始化是否在BRANCH中的数组
    for(int u=0;u<T.size();u++){
        isExistInBRANCH[T[u]]=1;
    }
    queue<int>q;
    q.push(T.front());
    while(!q.empty()){
        int u=q.front();
        q.pop();
        visit[u]=1;
        for(int j=g.head[u];j;j=g.Next[j]){
			int neighbor=g.ver[j];
            if(isExistInBRANCH[neighbor]==1&&visit[neighbor]==0){
				isEdgeInBRANCH[j]=1;isEdgeInBRANCH[j^1]=1;
                //treeneighbor[u].push_back(neighbor);
                //treeneighbor[neighbor].push_back(u);//给他的子节点中压入父节点邻居i
                visit[neighbor]=1;
                q.push(neighbor);
            }
        }
    }
}
int Genetic::computeEblocksNum(vector<int> S0andConnector,vector<int>&eblock_id){
    int EblocksNum=0;
    vector<int> computed;
    computed.clear();
    for(int u:S0andConnector){
        auto it=find(computed.begin(),computed.end(),eblock_id[u]);
        if(it==computed.end())computed.push_back(eblock_id[u]);
    }
    EblocksNum=int(computed.size());
    if(EblocksNum<=0)cout<<"EblockNum error!"<<endl;
    return EblocksNum;
}
int Genetic::findL1Connector(vector<int> S0andConnector,vector<int>&eblock_id){
    vector<int> isInS0andConnector(g.nodeNum+1,0);
    for(int u:S0andConnector){
        isInS0andConnector[u]=1;
    }
    vector<int> eblockArray;
    for(int u=1;u<=g.nodeNum;u++){
        if(isInS0andConnector[u]==0){
            eblockArray.clear();
            for(int j=g.head[u];j;j=g.Next[j]){
				int neighbor=g.ver[j];
                if(isInS0andConnector[neighbor]==1){
                    auto it=find(eblockArray.begin(),eblockArray.end(),eblock_id[neighbor]);
                    if(it==eblockArray.end())eblockArray.push_back(eblock_id[neighbor]);
                }
            }
            if(1<int(eblockArray.size()))return u;
        }
    }
    return -1;
}
pair<int,int> Genetic::findL2Connector(vector<int> S0andConnector,vector<int>&eblock_id){
	vector<int> isInS0andConnector(g.nodeNum+1,0);
    for(int u:S0andConnector){
        isInS0andConnector[u]=1;
    }
    vector<int> eblockArray;
    for(int u=1;u<=g.nodeNum;u++){
        if(isInS0andConnector[u]==0){
            for(int j=g.head[u];j;j=g.Next[j]){
				int v=g.ver[j];
                if(isInS0andConnector[v]==0){//找到一对不在树中（白色节点）的节点
                    eblockArray.clear();
            		for(int j=g.head[u];j;j=g.Next[j]){
						int neighbor_u=g.ver[j];
                        if(isInS0andConnector[neighbor_u]==1){
                            auto it=find(eblockArray.begin(),eblockArray.end(),eblock_id[neighbor_u]);
                            if(it==eblockArray.end())eblockArray.push_back(eblock_id[neighbor_u]);
                        }
                    }
            		for(int j=g.head[v];j;j=g.Next[j]){
						int neighbor_v=g.ver[j];
                        if(isInS0andConnector[neighbor_v]==1){
                            auto it=find(eblockArray.begin(),eblockArray.end(),eblock_id[neighbor_v]);
                            if(it==eblockArray.end())eblockArray.push_back(eblock_id[neighbor_v]);
                        }
                    }
                    if(1<int(eblockArray.size())){
                        pair<int,int> ans(u,v);
                        return ans;
                    }
                }
            }
        }
    }
    pair<int,int> ans(-1,-1);
    return ans;
}
bool Genetic::existBridge(vector<int> S0andConnector){
    vector<int>isInS0andConnector(g.nodeNum+1,0);
    for(int u=1;u<=g.nodeNum;u++){
        auto it=find(S0andConnector.begin(),S0andConnector.end(),u);
        if(it!=(S0andConnector.end()))isInS0andConnector[u]=1;
    }
    vector<int>dfn(g.nodeNum+1,0);//int型默认初始化为0
	vector<int>low(g.nodeNum+1,0);
	int bridgeNum=0;
	int tarjanNum=0;
	int num=0;	//connected component
	for(int i=1;i<=g.nodeNum;i++){
		if(!dfn[i]&&isInS0andConnector[i]==1){
			if(++num>1) return true;
			tarjan(i,0,isInS0andConnector,dfn,low,bridgeNum,tarjanNum);
		}
	}
	return bridgeNum>0;
}
void Genetic::tarjan(int x,int father,vector<int>&isInS0andConnector,vector<int>&dfn,vector<int>&low,int &bridgeNum,int &tarjanNum){
	/*dfn[x]=low[x]=++tarjanNum;
    for(int j=g.head[x];j;j=g.Next[j]){
		int neighbor=g.ver[j];
		if(isInS0andConnector[neighbor]==0||neighbor==father) continue;
		if(!dfn[neighbor]){
			tarjan(neighbor,x,isInS0andConnector,dfn,low,bridgeNum,tarjanNum);
			low[x]=min(low[x],low[neighbor]);
			if(dfn[x]<low[neighbor]) bridgeNum++;
		}else low[x]=min(low[x],dfn[neighbor]);
	}*/
	dfn[x]=low[x]=++tarjanNum;
	for(int i=g.head[x];i;i=g.Next[i]){
		if(isInS0andConnector[g.ver[i]]==0||i==(father^1)) continue;
		int y=g.ver[i];
		if(!dfn[y]){
			tarjan(y,i,isInS0andConnector,dfn,low,bridgeNum,tarjanNum);
			low[x]=min(low[x],low[y]);
			if(dfn[x]<low[y]) bridgeNum++;
		}else low[x]=min(low[x],dfn[y]);
	}
}


void Genetic::expenDominating(vector<int>&S){
	vector<int>dominating(g.nodeNum+1,0);
	vector<int>B0;B0.clear();
    bool judge=computeDominated(S,dominating);
    if(judge==false)cout<<"dominated error!"<<endl;
    while(computeOneDominatedNode(S,dominating,B0)){
        int maxnode=B0.back();
        int nodeB0Neighbor=computeB0Neighbor(S,B0,maxnode);
        for(int u:B0){
            if(g.degree[u]>g.degree[maxnode]){
                maxnode=u;
                nodeB0Neighbor=computeB0Neighbor(S,B0,maxnode);
            }
            else if((g.degree[u]==g.degree[maxnode])&&(computeB0Neighbor(S,B0,u)>nodeB0Neighbor)){
                maxnode=u;
                nodeB0Neighbor=computeB0Neighbor(S,B0,maxnode);
            }
            else if((g.degree[u]==g.degree[maxnode])&&(computeB0Neighbor(S,B0,u)==nodeB0Neighbor)&&(u<maxnode)){
                maxnode=u;
                nodeB0Neighbor=computeB0Neighbor(S,B0,maxnode);
            }
        }
        S.push_back(maxnode);
		S[maxnode]=1;
        computeDominated(S,dominating);
    }
	/*			for(int nodede=1;nodede<=g.nodeNum;nodede++){
					if(S[nodede]==0&&dominating[nodede]<m_size){cout<<"de result error!"<<endl;}
				}*/	
}
bool Genetic::computeDominated(vector<int>&S,vector<int>&dominating){
    dominating.clear();
    dominating.assign(g.nodeNum+1,0);
    for(int u=1;u<=g.nodeNum;u++){
        for(int j=g.head[u];j;j=g.Next[j]){
			int neighbor=g.ver[j];
            if(S[neighbor]==1){
                dominating[u]++;
            }
        }
        if(dominating[u]==0){cout<<"errorrr"<<endl;return false;}
    }
    return true;
}
int Genetic::computeOneDominatedNode(vector<int>&S,vector<int>&dominating,vector<int>&B0){
    int num=0;
    B0.clear();
    for(int u=1;u<=g.nodeNum;u++){
        if(S[u]==0&&dominating[u]==1){num++;B0.push_back(u);}
    }
    return num;
}
int Genetic::computeB0Neighbor(vector<int>&S,vector<int>&B0,int node){
    if(B0.size()==0)cout<<"B0 error"<<endl;
    int num=0;
    for(int u:B0){
        for(int j=g.head[node];j;j=g.Next[j]){
			int neighbor=g.ver[j];
            if(neighbor==u)num++;
        }
    }
    return num;
}

void Genetic::refine_SandDelete(vector<int>&S){
	int pivotNodeNum,tot;
	map<int,int> newNode;
	vector<int> oriNode,ver,weight,Next,head;
	vector<vector<int>> newEdgeNode;
	reConstruct(S,newNode,oriNode,ver,weight,Next,head,newEdgeNode,pivotNodeNum,tot);
	int bridgeNum,tarjanNum,updated;
	int updateInformation;
	vector<tuple<int,Type,int>> canDeleteList;
	vector<int> logicDelete,tempLogicDelete,dfn,low,bestSol,onlyDom,logicDeleteNode,beDominated;
	logicDelete.assign(tot+10,0);
	tempLogicDelete.assign(tot+10,0);
	onlyDom.assign(g.nodeNum+1,0);
	logicDeleteNode.assign(g.nodeNum+1,0);
	beDominated.assign(g.nodeNum+1,0);
	//isSelected=c.isSelected;	// copy
	//beDominated=c.beDominated;	// copy
	canDeleteList.clear();
	for(int i=1;i<=g.nodeNum;i++){
		if(S[i]==1) {beDominated[i]+=m_size;
			for(int j=g.head[i];j;j=g.Next[j]){
				int y=g.ver[j];
				beDominated[y]++;
		}
		}
		//for(int y : g.edge[x]) if(++beDominated[y]==1) unDominatedNum--;
	}
	for(int i=1;i<=g.nodeNum;i++){
		if(beDominated[i]!=m_size) continue;
		for(int j=g.head[i];j;j=g.Next[j]){
			int y=g.ver[j];
			if(S[y]) onlyDom[y]=1;//找出被支配的点仅有一条边和耳相连，并记录，在下面设置为该解中的点不能删除
		}
	}
	for(int i=2;i<tot;i+=2){//这里之所以选取2可以看看重构最后的newEdgeNode，tot 保存新的边的数量
		if(m_size==2){
			if(weight[i]==1){
				bool canNotdelete=0;
				for(int y : newEdgeNode[i]){
					if(onlyDom[y]==1){
						canNotdelete=1;
						break;
					}
				}
				if(canNotdelete==0)
					canDeleteList.push_back(make_tuple(weight[i],Type::EDGE,i));//这是第i个边，权重为weight[i]，不能删除//这里记录可删除的边
			}
		}
		else {
			if(weight[i]>0&&weight[i]<=2){
				bool canNotdelete=0;
				for(int y : newEdgeNode[i]){
					if(onlyDom[y]==1){
						canNotdelete=1;
						break;
					}
				}
				if(canNotdelete==0)
					canDeleteList.push_back(make_tuple(weight[i],Type::EDGE,i));//这是第i个边，权重为weight[i]，不能删除//这里记录可删除的边
			}
		}
	}
	for(int i=1;i<=pivotNodeNum;i++){//pivotnodenum是重构后节点的数量
		int weight_2=0,weight_0=0,nodeWeight=1;
		for(int j=head[i];j;j=Next[j]){
			int w=weight[j];
			nodeWeight+=w;
			if(w>=2) weight_2++;
			else if(w==0) weight_0++;
		}
		if(weight_2==0&&weight_0!=0&&onlyDom[oriNode[i]]==0)
			canDeleteList.push_back(make_tuple(nodeWeight,Type::NODE,i));//记录可删除的顶点
	}
#ifdef GREEDY
	greedyRandomDelete(canDeleteList);
#else
	randomDelete(S,logicDelete,tempLogicDelete,beDominated,newEdgeNode,pivotNodeNum,logicDeleteNode,head,Next,ver,oriNode,canDeleteList);
#endif
	for(int i=2;i<(int)logicDelete.size();i+=2){
		if(logicDelete[i]==0) continue;
		for(int x : newEdgeNode[i]){
			S[x]=0;
		}
	}
	for(int i=1;i<=g.nodeNum;i++) if(logicDeleteNode[i]) S[oriNode[i]]=0;
	int weightSum=0;
	for(int i=1;i<=g.nodeNum;i++) weightSum+=S[i];
}
void Genetic::randomDelete(vector<int>&S,vector<int> &logicDelete,vector<int> &tempLogicDelete,vector<int>&beDominated,vector<vector<int>>& newEdgeNode,int &pivotNodeNum,vector<int>&logicDeleteNode,vector<int>&head,vector<int>&Next,vector<int> &ver,vector<int> &oriNode,vector<tuple<int,Type,int>> &canDeleteList){
    random_shuffle(canDeleteList.begin(),canDeleteList.end());
	for(auto &e : canDeleteList){
		if(get<1>(e)==Type::EDGE)
			deleteEdge(S,logicDelete,tempLogicDelete,beDominated,newEdgeNode,pivotNodeNum,logicDeleteNode,head,Next,ver,get<0>(e),get<2>(e));
		else if(get<1>(e)==Type::NODE)
			deleteNode(S,logicDelete,tempLogicDelete,beDominated,newEdgeNode,pivotNodeNum,logicDeleteNode,head,Next,ver,oriNode,get<0>(e),get<2>(e));
	}
}
int Genetic::deleteEdge(vector<int>&S,vector<int>& logicDelete,vector<int>& tempLogicDelete,vector<int>&beDominated,vector<vector<int>> &newEdgeNode,int &pivotNodeNum,vector<int>&logicDeleteNode,vector<int>&head,vector<int>&Next,vector<int> &ver,int weight,int index){
	if(logicDelete[index]) return 0;
	//if(!existBridge(logicDeleteNode,pivotNodeNum,logicDelete,tempLogicDelete,head,Next,ver)){
	if(!checkDeleteEdgeDom(logicDelete,tempLogicDelete,beDominated,newEdgeNode,index)) return 0;//检查删除后会不会有未被支配的节点
	tempLogicDelete[index]=1;
	tempLogicDelete[index^1]=1;	// pairwise transformation//假设这条边被删除
	if(!existBridge(logicDeleteNode,pivotNodeNum,logicDelete,tempLogicDelete,head,Next,ver)){
		logicDelete[index]=1;
		logicDelete[index^1]=1;
		return weight;
	}
	tempLogicDelete[index]=0;
	tempLogicDelete[index^1]=0;
	/*for(int x : r.newEdgeNode[index]){
		beDominated[x]++;
		for(int i=g.head[x];i;i=g.Next[i]){
			int y=g.ver[i];
			beDominated[y]++;
		}
	}*/
	return 0;
}
bool Genetic::checkDeleteEdgeDom(vector<int>& logicDelete,vector<int>& tempLogicDelete,vector<int>&beDominated,vector<vector<int>>& newEdgeNode,int index){
	bool ret=1;	
	for(int x : newEdgeNode[index]){
		if(beDominated[x]<=m_size+m_size-1){ beDominated[x]-=m_size;ret=0;}
		else beDominated[x]-=m_size;
		for(int i=g.head[x];i;i=g.Next[i]){
			int y=g.ver[i];
			if(--beDominated[y]<=m_size-1) ret=0;
		}
	}
	if(ret==1) return true;
	for(int x : newEdgeNode[index]){
		beDominated[x]+=m_size;
		for(int i=g.head[x];i;i=g.Next[i]){
			int y=g.ver[i];
			beDominated[y]++;
		}
	}
	return false;
}
bool Genetic::existBridge(vector<int>&logicDeleteNode,int &pivotNodeNum,vector<int>& logicDelete,vector<int>& tempLogicDelete,vector<int>&head,vector<int>&Next,vector<int> &ver){
	vector<int>dfn(pivotNodeNum+1,0);//int型默认初始化为0
	vector<int>low(pivotNodeNum+1,0);
	int bridgeNum=0;
	int tarjanNum=0;
	int num=0;	//connected component
	for(int i=1;i<=pivotNodeNum;i++){
		if(!dfn[i]&&logicDeleteNode[i]==0){
			if(++num>1) return true;
			tarjan(i,0,dfn,low,tarjanNum,bridgeNum,logicDelete,tempLogicDelete,head,Next,ver);
		}
	}
	return bridgeNum>0;
}
void Genetic::tarjan(int x,int faEdge,vector<int>&dfn,vector<int>&low,int &tarjanNum,int &bridgeNum,vector<int>& logicDelete,vector<int>& tempLogicDelete,vector<int>&head,vector<int>&Next,vector<int> &ver){
	dfn[x]=low[x]=++tarjanNum;
	for(int i=head[x];i;i=Next[i]){
		if(tempLogicDelete[i]||logicDelete[i]||i==(faEdge^1)) continue;
		int y=ver[i];
		if(!dfn[y]){
			tarjan(y,i,dfn,low,tarjanNum,bridgeNum,logicDelete,tempLogicDelete,head,Next,ver);
			low[x]=min(low[x],low[y]);
			if(dfn[x]<low[y]) bridgeNum++;
		}else low[x]=min(low[x],dfn[y]);
	}
}
int Genetic::deleteNode(vector<int>&S,vector<int>& logicDelete,vector<int>& tempLogicDelete,vector<int>&beDominated,vector<vector<int>> &newEdgeNode,int &pivotNodeNum,vector<int>&logicDeleteNode,vector<int>&head,vector<int>&Next,vector<int> &ver,vector<int> &oriNode,int weight,int index){
	vector<int> deleteList;
	if(!checkDeleteNodeDom(logicDelete,tempLogicDelete,beDominated,newEdgeNode,oriNode,head,Next,deleteList,index)) return 0;//检查删除后会不会有未被支配的节点
	for(int i=head[index];i;i=Next[i]){
		tempLogicDelete[i]=1;
		tempLogicDelete[i^1]=1;//假设这个定点的周围的边被删除
	}
	logicDeleteNode[index]=1;
	if(!existBridge(logicDeleteNode,pivotNodeNum,logicDelete,tempLogicDelete,head,Next,ver)){
		for(int i=head[index];i;i=Next[i]){
			logicDelete[i]=1;
			logicDelete[i^1]=1;
		}
		return weight;
	}
	logicDeleteNode[index]=0;
	for(int i=head[index];i;i=Next[i]){
		tempLogicDelete[i]=0;
		tempLogicDelete[i^1]=0;
	}
	return 0;
}
bool Genetic::checkDeleteNodeDom(vector<int>& logicDelete,vector<int>& tempLogicDelete,vector<int>&beDominated,vector<vector<int>>& newEdgeNode,vector<int>& oriNode,vector<int>&head,vector<int>&Next,vector<int> &deleteList,int index){
	bool ret=1;	
	deleteList.push_back(oriNode[index]);
	for(int i=head[index];i;i=Next[i]){
		if(logicDelete[i]||tempLogicDelete[i]) continue;
		int tempI=min(i,i^1);
		for(int x : newEdgeNode[tempI]) deleteList.push_back(x);
	}
	for(int x : deleteList){
		if(beDominated[x]<=m_size+m_size-1){ beDominated[x]-=m_size;ret=0;}
		else beDominated[x]-=m_size;
		for(int i=g.head[x];i;i=g.Next[i]){
			int y=g.ver[i];
			if(--beDominated[y]<=m_size-1) ret=0;
		}
	}	
	if(ret==1) return true;
	for(int x : deleteList){
		beDominated[x]+=m_size;
		for(int i=g.head[x];i;i=g.Next[i]){
			int y=g.ver[i];
			beDominated[y]++;
		}
	}	
	return false;
}


void Genetic::reConstruct(vector<int>&S,map<int,int>&newNode,vector<int> &oriNode,vector<int>&ver,vector<int>&weight,vector<int>&Next,vector<int>&head,vector<vector<int>> &newEdgeNode,int &pivotNodeNum,int &tot){
	newNode.clear();
	oriNode.clear(); oriNode.push_back(0);
	ver.clear(); ver.push_back(0); ver.push_back(0);
	weight.clear(); weight.push_back(0); weight.push_back(0);
	Next.clear(); Next.push_back(0); Next.push_back(0);
	newEdgeNode.clear();
	newEdgeNode.push_back(vector<int>());
	newEdgeNode.push_back(vector<int>());
	pivotNodeNum=0;
	tot=1;
	for(int i=1;i<=g.nodeNum;i++){
		if(!S[i]) continue;//c即前一步的构造初始解中的一个解，isselect虽然表示一个节点是否被选中作为解，但是他在更新时以一个耳的节点为整体更新的详见MergeEar
		int neiInEar=0;
		for(int j=g.head[i];j;j=g.Next[j]){
			int y=g.ver[j];
			if(S[y]) neiInEar++;
		}
		if(neiInEar>2){
			oriNode.push_back(i);//与下方的newnode共同构成相对绝对位置的转换
			newNode[i]=++pivotNodeNum;//重构中优化节点的方式，将度大于三的节点保存起来，其他节点就自动变为被压缩得边
		}
	}
	head=vector<int>(pivotNodeNum+10,0);
	for(int i=1;i<(int)oriNode.size();i++){
		int x=oriNode[i];
		for(int j=g.head[x];j;j=g.Next[j]){
			int y=g.ver[j];
			if(!S[y]) continue;
			int z,w;
			vector<int> pathNode;
			tie(z,w)=getEnd(S,newNode,y,j,0,pathNode);//递归返回z：这条优化边的最后一个NewNode节点（非优化边节点）  w：这条边上被优化的节点数
			if(z>=x){
				add(ver,weight,Next,head,tot,newNode[x],newNode[z],w);
				add(ver,weight,Next,head,tot,newNode[z],newNode[x],w);
				newEdgeNode.emplace_back(pathNode);
				newEdgeNode.push_back(vector<int>());
			}
		}
	}
}
pair<int,int> Genetic::getEnd(vector<int>&S,map<int,int>&newNode,int x,int faPath,int dis,vector<int> &pathNode){
	if(newNode.count(x)) return {x,dis};//递归出口
	for(int i=g.head[x];i;i=g.Next[i]){
		int y=g.ver[i];
		if(i==(faPath^1)||!S[y]) continue;//排除返回原先节点的可能
		pathNode.push_back(x);
		return getEnd(S,newNode,y,i,dis+1,pathNode);//递归,其中，dis记录深度(节点数)，pathnode记录这条路径上的节点,而y会因为递归传递返回最后一次访问到的节点，这个节点是NewNode中的节点
	}
	printf("Error in 'getEnt(%d,%d)'.\n",x,faPath);
	return {0,0};	// impossible
}
void Genetic::add(vector<int>&ver,vector<int>&weight,vector<int>&Next,vector<int>&head,int& tot,int u,int v,int w){
	//ver[++tot]=v,Next[tot]=head[u],head[u]=tot,weight[tot]=w;
	ver.push_back(v),Next.push_back(head[u]),weight.push_back(w),head[u]=++tot;
}















/*


void Genetic::computeblocks(vector<int>&S,vector<int>&id){
	vector<int> vis;
	vector<int> father;
    vector<int> inQ(g.nodeNum+1,0);
	id.assign(g.nodeNum+1,0);
	vis.assign(g.nodeNum+1,0);
	father.assign(g.nodeNum+1,0);
	for(int i=1;i<=g.nodeNum;i++){
		if(S[i]==0&&vis[i]!=0)continue;//不是集和中的点或者已经被访问的点不考虑；
		int temp;
		queue<int> Q;
		Q.push(i);
		vis[i]=1;
		id[i]=i;
		inQ[i]=1;
		while(!Q.empty()){
			temp=Q.front();
			Q.pop();
			for(int j=g.head[temp];j;j=g.Next[j]){
				if(j==(father[temp]^1)) continue;
				int y=g.ver[j];
				if(vis[y]==0||S[y]==0){
					vis[y]=0;
					Q.push(y);
					inQ[i]=1;
					father[y]=j;
				}else if(vis[y]==1||S[y]==0){

				}
			}
		}
	}//计算当前集和中的block块，并对同一块中的元素更改相同的id;
}
int Genetic::computeblocksnum(vector<int>&S,vector<int>&id){
    int blocksNum=0;
    vector<int> computed;
    computed.clear();
    for(int i=1;i<=g.nodeNum;i++){
        auto it=find(computed.begin(),computed.end(),id[i]);
        if(it==computed.end())computed.push_back(id[i]);
    }
    blocksNum=int(computed.size());
    if(blocksNum<=0)cout<<"EblockNum error!"<<endl;
    return blocksNum;
}
*/