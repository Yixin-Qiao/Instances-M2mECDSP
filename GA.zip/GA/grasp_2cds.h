#ifndef GRASP_2CDS_H_INCLUDED
#define GRASP_2CDS_H_INCLUDED

#include<iostream>
#include<set>
#include<map>
#include<vector>
#include<ctime>
#include<algorithm>
#include<queue>
#include<climits>
#include<cstdio>
#include<sys/times.h>
#include<sys/time.h>

#include<unistd.h>
//#define TEST
//#define LOG
//#define GREEDY
using namespace std;

extern FILE *logfp;
extern double ratio;

struct Graph{
	int nodeNum,tot;
	//vector<vector<int>> edge;
	vector<int> head,ver,Next;
	vector<int> vis;
	vector<int> degree;

	void add(int u,int v);
	void input(char *fileName);
	void randomEdge();
	bool isConnected();
	void init();
};

struct EarDec{  // Already abandoned, replaced by ED
	Graph &g;
	int earNum;
	vector<int> vis,inStack,dfsStack,earIndex,prefix,du;
	vector<vector<int>> earEdge,earNodeList;
	set<pair<int,int>> repeatRely;

	EarDec(Graph &g):g(g){}
	void dfs(int x,int fa);
	void addPrefix(int index,int val);
	void addEar(int index);
	void addEar(int x,int);
	void addRely(int u,int v);
	void init();
    void earDecompose(int root);
};

struct ED{
	Graph &g;
	int earNum,hasEval;
	vector<int> vis,faPath,earIndex,du;
	vector<vector<int>> earEdge,earNodeList;
	set<pair<int,int>> repeatRely;

	ED(Graph &g):g(g){}
	void init();
	void earDecompose(int root);
	bool addEar(int x,int y);
	void addRely(int u,int v);
    void bfs(int bfsTimes,int root);
};



struct Construct{
	ED &e;
	Graph &g;
	int unDominatedNum;
	int tabu_;
	vector<int> canMergeList,isSelected,beDominated,du;
	vector<double> earScore;
	queue<int> nexttopQueue;
	vector<int>nextcanMergeList;
	double beta;

	Construct(ED &e,double b):e(e),g(e.g){beta=b;}
	bool lsconstructSolution(vector<double> &information,int m_size);
	void init();
	void mergeEar(int index,int m_size);
	void calEarScore(vector<double> &information,int m_size);
};

struct Rebuilder{
	Construct &c;
	ED &e;
	Graph &g;
	int pivotNodeNum,tot;
	map<int,int> newNode;
	vector<int> oriNode,ver,weight,Next,head;
	vector<vector<int>> newEdgeNode;

	Rebuilder(Construct &c):c(c),e(c.e),g(c.g){}
	void reConstructGraph();
	pair<int,int> getEnd(int x,int fa,int dis,vector<int> &pathNode);
	void add(int u,int v,int w);
	void init();
};

struct Deleter{
	Rebuilder &r;
	Construct &c;
	ED &e;
	Graph &g;
	int bridgeNum,tarjanNum,bestAns=INT_MAX,updated;
	int updateInformation;
	int m_size;
	int transformans;
	enum class Type{ EDGE, NODE };
	vector<tuple<int,Type,int>> canDeleteList;
	vector<int> logicDelete,tempLogicDelete,dfn,low,isSelected,bestSol,onlyDom,logicDeleteNode,beDominated;	// local isSelected

	Deleter(Rebuilder &r):r(r),c(r.c),e(r.e),g(r.g){}
	void deleteUselessNode(int msize);
	int deleteEdge(int weight,int index);
	int deleteNode(int weight,int index);
	bool existBridge();
	void tarjan(int x,int faEdge);
	void init();
	void updateResult(int ans);
	void ptResult();
	bool checkDeleteEdgeDom(int index);
	bool checkDeleteNodeDom(vector<int>& deleteList,int index);
	void greedyRandomDelete(vector<tuple<int,Type,int>> &list);
	void randomDelete(vector<tuple<int,Type,int>> &list);
};

class Random{
	vector<int> buffer;
	int cnt;
	public:
	Random(int x);
	int get();
};

template<typename VECTOR>
void initVec(VECTOR &v,int sz,int val=0){
//void initVec(vector<int> &v,int sz,int val){
	v.reserve(sz);
	v.resize(sz);
	v.assign(v.size(),val);
}
struct AntCompute{
	void InitialInformation(vector<double>&information,int NodeNum);
	void ComputeInformation(vector<double>&information,int NodeNum,vector<int>&select,double p);
	
};
struct Genetic{
	enum class Type{ EDGE, NODE };
	Graph &g;
	vector<vector<int>>RS;vector<int>RSvalue;
	vector<vector<int>>FS;vector<int>FSvalue;
	vector<vector<int>>ARS;vector<int>ARSvalue;
	int tag;
	int m_size;
	int RSsize,FSsize;
	float crosssize,mutationsize;
	int bestans;
	void init(int a,int b,float c,float d);
	void select();
	void cross();
	void mutation();
	void correct();
	void deleteAloneNode(vector<int>&S);
	void selectFromARSToRS(int a);
	int ECDS(vector<int>&S);
	void connected(vector<int>&S);
	void PDS(vector<int>&S);
	int PDSdeleteDominatingNode(vector<int>&S,vector<int>&tag);
	void findConnectedDominatingSet(vector<int>&S);
	void bfs(vector<int>&S,vector<int>&component);
	bool allComponentsConnected(vector<int>&S,vector<int>&component);
	int findCanMergeConnectors(vector<int>&S,vector<int>&component);

	void computeECDS(vector<int>&S0);
	void computeEblocks(vector<int>S0andConnector,vector<int>&isBlue,vector<int>&isWhite,vector<int>&isRed,vector<int>&eblock_id);
	void constructBFSTree(vector<int> T,vector<int>&isExistInBRANCH,vector<vector<int>>&treeneighbor,vector<int>&isEdgeInBRANCH);
	int computeEblocksNum(vector<int> S0andConnector,vector<int>&eblock_id);
	int findL1Connector(vector<int> S0andConnector,vector<int>&eblock_id);
	pair<int,int> findL2Connector(vector<int> S0andConnector,vector<int>&eblock_id);
	bool existBridge(vector<int> S0andConnector);
	void tarjan(int x,int father,vector<int>&isInS0andConnector,vector<int>&dfn,vector<int>&low,int& bridgeNum,int& tarjanNum);

	void expenDominating(vector<int>&S);
	bool computeDominated(vector<int>&S,vector<int>&dominating);
	int computeOneDominatedNode(vector<int>&S,vector<int>&dominating,vector<int>&B0);
	int computeB0Neighbor(vector<int>&S,vector<int>&B0,int node);

	void refine_SandDelete(vector<int>&S);

	void andDelete(vector<int>&S);
	bool existBridge(vector<int>&S,vector<int>&logicDelete);
	void tarjan(int x,int faEdge,vector<int>&S,vector<int>&logicDelete,vector<int>&dfn,vector<int>&low,int &bridgeNum,int &tarjanNum);

	void reConstruct(vector<int>&S,map<int,int>&newNode,vector<int> &oriNode,vector<int>&ver,vector<int>&weight,vector<int>&Next,vector<int>&head,vector<vector<int>> &newEdgeNode,int &pivotNodeNum,int &tot);
	pair<int,int> getEnd(vector<int>&S,map<int,int>&newNode,int x,int faPath,int dis,vector<int> &pathNode);
	void add(vector<int>&ver,vector<int>&weight,vector<int>&Next,vector<int>&head,int& tot,int u,int v,int w);

	void deleteUselessNode(vector<int>&S,int m_size);
	void randomDelete(vector<int>&S,vector<int>& logicDelete,vector<int>& tempLogicDelete,vector<int>&beDominated,vector<vector<int>>& newEdgeNode,int &pivotNodeNum,vector<int>&logicDeleteNode,vector<int>&head,vector<int>&Next,vector<int> &ver,vector<int> &oriNode,vector<tuple<int,Type,int>> &canDeleteList);
	int deleteEdge(vector<int>&S,vector<int>& logicDelete,vector<int>& tempLogicDelete,vector<int>&beDominated,vector<vector<int>>& newEdgeNode,int &pivotNodeNum,vector<int>&logicDeleteNode,vector<int>&head,vector<int>&Next,vector<int> &ver,int weight,int index);
	bool checkDeleteEdgeDom(vector<int>& logicDelete,vector<int>& tempLogicDelete,vector<int>&beDominated,vector<vector<int>>& newEdgeNode,int index);
	bool existBridge(vector<int>&logicDeleteNode,int &pivotNodeNum,vector<int>& logicDelete,vector<int>& tempLogicDelete,vector<int>&head,vector<int>&Next,vector<int> &ver);
	void tarjan(int x,int faEdge,vector<int>&dfn,vector<int>&low,int& tarjanNum,int& bridgeNum,vector<int>& logicDelete,vector<int>& tempLogicDelete,vector<int>&head,vector<int>&Next,vector<int> &ver);
	int deleteNode(vector<int>&S,vector<int>& logicDelete,vector<int>& tempLogicDelete,vector<int>&beDominated,vector<vector<int>> &newEdgeNode,int &pivotNodeNum,vector<int>&logicDeleteNode,vector<int>&head,vector<int>&Next,vector<int> &ver,vector<int>& oriNode,int weight,int index);
	bool checkDeleteNodeDom(vector<int>& logicDelete,vector<int>& tempLogicDelete,vector<int>&beDominated,vector<vector<int>>& newEdgeNode,vector<int>& oriNode,vector<int>&head,vector<int>&Next,vector<int> &deleteList,int index);

	void computeblocks(vector<int>&S,vector<int>&id);
	int computeblocksnum(vector<int>&S,vector<int>&id);
	void dominating(vector<int>&S);

	Genetic(Graph &g,int m,int best):g(g){
		m_size=m;
		bestans=best;
	}
};
#endif // GRASP_2CDS_H_INCLUDED
